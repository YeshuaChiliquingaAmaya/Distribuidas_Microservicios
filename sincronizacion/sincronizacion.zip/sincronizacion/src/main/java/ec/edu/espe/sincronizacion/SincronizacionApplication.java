package ec.edu.espe.sincronizacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SincronizacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SincronizacionApplication.class, args);
	}

}
